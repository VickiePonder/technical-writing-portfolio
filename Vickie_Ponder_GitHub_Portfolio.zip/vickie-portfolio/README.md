# Vickie Ponder — Technical Writing Portfolio

Static, responsive, single-file portfolio website. No build tools, dependencies, analytics, or tracking.

## Publish free on GitHub Pages
1. Create a **public** GitHub repository named `technical-writing-portfolio`.
2. Upload `index.html` to the repository root and commit to `main`.
3. Open repository **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**, `main`, `/ (root)`; save.
5. Your website URL will be `https://YOUR-USERNAME.github.io/technical-writing-portfolio/` after deployment.

GitHub Pages sites are publicly accessible. Do not upload confidential client documents. This portfolio contains only high-level case studies.
